touch from
touch to
echo "I am Syed Arham Ahmed" > from
echo "My roll number is 22i-1552" >> from
cp from to
rm from
mv to final_file
grep Arham final_file
echo tasK1DONE
