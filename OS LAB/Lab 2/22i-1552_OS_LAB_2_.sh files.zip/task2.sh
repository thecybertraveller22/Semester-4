touch count
echo "1" > count
echo "2" >> count
echo "3" >> count
echo "4" >> count
echo "5" >> count
echo "6" >> count
echo "7" >> count
echo "8" >> count
echo "9" >> count

sort -r count
echo sortedYay!


