echo Name: $1 $2 $3
echo Marks Total: $4
echo English: $5
echo Urdu: $6
echo Maths: $7
echo OSLAB: $8

