cd 
cd Documents
rm Temp3
cd
cd Desktop
rm Temp2
cd
cd Desktop
cd "OS LAB"
rm Temp
cd
echo deletedALLTempFiles
